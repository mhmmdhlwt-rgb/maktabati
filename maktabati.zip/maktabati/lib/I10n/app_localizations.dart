import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'app_localizations_en.dart';
import 'app_localizations_ar.dart';

class AppLocalizations {
  final Locale locale;

  AppLocalizations(this.locale);

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  late final _strings = _localizedStrings[locale.languageCode]!;

  String get appTitle => _strings['appTitle']!;
  String get welcomeMessage => _strings['welcomeMessage']!;
  String get enterLibrary => _strings['enterLibrary']!;
  String get dashboard => _strings['dashboard']!;
  String get readFromBeginning => _strings['readFromBeginning']!;
  String get continueReading => _strings['continueReading']!;
  String get bookmarks => _strings['bookmarks']!;
  String get settings => _strings['settings']!;
  String get search => _strings['search']!;
  // ... tambahkan kunci lain sesuai kebutuhan
}

final _localizedStrings = {
  'en': enStrings,
  'ar': arStrings,
};

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => ['en', 'ar'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async {
    return AppLocalizations(locale);
  }

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}