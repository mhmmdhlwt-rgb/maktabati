import 'package:flutter/material.dart';

class AppTextStyles {
  // Arabic text styles (adjust with font family dynamic)
  static TextStyle matan(BuildContext context, {Color? color, double? fontSize, String? fontFamily}) {
    return TextStyle(
      fontFamily: fontFamily ?? 'Amiri',
      fontSize: fontSize ?? 24,
      fontWeight: FontWeight.bold,
      color: color ?? Theme.of(context).colorScheme.onSurface,
      height: 1.8,
    );
  }

  static TextStyle syarah(BuildContext context, {Color? color, double? fontSize, String? fontFamily}) {
    return TextStyle(
      fontFamily: fontFamily ?? 'Amiri',
      fontSize: fontSize ?? 18,
      fontWeight: FontWeight.normal,
      color: color ?? Theme.of(context).colorScheme.onSurface.withOpacity(0.85),
      height: 1.6,
    );
  }

  static TextStyle terjemah(BuildContext context, {Color? color, double? fontSize}) {
    return TextStyle(
      fontFamily: 'Inter',
      fontSize: fontSize ?? 14,
      fontWeight: FontWeight.normal,
      color: color ?? Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
      height: 1.4,
    );
  }

  static TextStyle uiTitle(BuildContext context) {
    return TextStyle(
      fontFamily: 'Inter',
      fontSize: 20,
      fontWeight: FontWeight.w600,
      color: Theme.of(context).colorScheme.onSurface,
    );
  }

  static TextStyle uiBody(BuildContext context) {
    return TextStyle(
      fontFamily: 'Inter',
      fontSize: 16,
      color: Theme.of(context).colorScheme.onSurface.withOpacity(0.8),
    );
  }
}