import 'package:flutter/material.dart';

class AppColors {
  // Cream Paper (default light)
  static const creamBg = Color(0xFFFDF8F0);
  static const creamText = Color(0xFF3E2C1F);
  static const creamSyarah = Color(0xFF5C4B3A);
  static const creamTerjemah = Color(0xFF8E7B6B);
  static const creamAccent = Color(0xFFB89B72);
  static const creamSurface = Color(0xFFFFFFFF);
  static const creamGlass = Color(0x66FFFFFF);

  // Dark Emerald
  static const emeraldBg = Color(0xFF1A2E1F);
  static const emeraldText = Color(0xFFD4E0C5);
  static const emeraldSyarah = Color(0xFFA3B89A);
  static const emeraldTerjemah = Color(0xFF7E8B75);
  static const emeraldAccent = Color(0xFF6B8F5E);
  static const emeraldSurface = Color(0xFF243B2A);
  static const emeraldGlass = Color(0x33243B2A);

  // Midnight Black
  static const midnightBg = Color(0xFF121212);
  static const midnightText = Color(0xFFEEEEEE);
  static const midnightSyarah = Color(0xFFCCCCCC);
  static const midnightTerjemah = Color(0xFF999999);
  static const midnightAccent = Color(0xFFBBBBBB);
  static const midnightSurface = Color(0xFF1E1E1E);
  static const midnightGlass = Color(0x33FFFFFF);

  // Soft Sepia
  static const sepiaBg = Color(0xFFF4ECD8);
  static const sepiaText = Color(0xFF5B4636);
  static const sepiaSyarah = Color(0xFF7D6253);
  static const sepiaTerjemah = Color(0xFF9E8A7A);
  static const sepiaAccent = Color(0xFFC5A47E);
  static const sepiaSurface = Color(0xFFFFF6E8);
  static const sepiaGlass = Color(0x66FFFFFF);

  // Minimal White
  static const whiteBg = Color(0xFFFFFFFF);
  static const whiteText = Color(0xFF212121);
  static const whiteSyarah = Color(0xFF424242);
  static const whiteTerjemah = Color(0xFF757575);
  static const whiteAccent = Color(0xFFBDBDBD);
  static const whiteSurface = Color(0xFFF5F5F5);
  static const whiteGlass = Color(0x33FFFFFF);
}