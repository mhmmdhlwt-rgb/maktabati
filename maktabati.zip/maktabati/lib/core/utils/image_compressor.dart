import 'dart:convert';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:universal_html/html.dart' as html;

class ImageCompressor {
  static Future<String?> pickAndCompress({int maxWidth = 400, int quality = 80}) async {
    final picker = ImagePicker();
    final XFile? imageFile = await picker.pickImage(source: ImageSource.gallery);
    if (imageFile == null) return null;
    final bytes = await imageFile.readAsBytes();
    return await compressFromBytes(bytes, maxWidth: maxWidth, quality: quality);
  }

  static Future<String?> compressFromBytes(Uint8List bytes, {int maxWidth = 400, int quality = 80}) async {
    final originalImage = img.decodeImage(bytes);
    if (originalImage == null) return null;
    final resized = img.copyResize(originalImage, width: maxWidth);
    final jpg = img.encodeJpg(resized, quality: quality);
    return base64Encode(jpg);
  }
}