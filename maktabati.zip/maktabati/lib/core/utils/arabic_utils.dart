class ArabicUtils {
  static String removeDiacritics(String text) {
    return text.replaceAll(RegExp(r'[\u064B-\u065F\u0610-\u061A\u06D6-\u06ED]'), '');
  }

  static String normalizeAlif(String text) {
    return text
        .replaceAll('أ', 'ا')
        .replaceAll('إ', 'ا')
        .replaceAll('آ', 'ا');
  }

  static String normalizeForSearch(String text) {
    return removeDiacritics(normalizeAlif(text));
  }
}