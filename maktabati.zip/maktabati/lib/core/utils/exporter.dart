import 'package:maktabati/data/models/bab.dart';
import 'package:maktabati/data/models/sub_bab.dart';
import 'package:maktabati/data/models/content_block.dart';

class KitabExporter {
  static String export({
    required String title,
    required String author,
    required List<Bab> babs,
  }) {
    final buffer = StringBuffer();
    buffer.writeln(title);
    buffer.writeln('AUTHOR: $author');
    buffer.writeln('===');
    for (var bab in babs) {
      buffer.writeln('= ${bab.title}');
      if (bab.subBabs != null) {
        for (var sub in bab.subBabs!) {
          buffer.writeln('== ${sub.title}');
          if (sub.contents != null) {
            for (var block in sub.contents!) {
              buffer.writeln('[MATAN]');
              buffer.writeln(block.matan);
              buffer.writeln('[SYARAH]');
              buffer.writeln(block.syarah);
              buffer.writeln('[TERJEMAH]');
              buffer.writeln(block.terjemah);
              buffer.writeln('---');
            }
          }
        }
      }
    }
    return buffer.toString();
  }
}