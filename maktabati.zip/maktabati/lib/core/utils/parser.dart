import 'package:maktabati/data/models/bab.dart';
import 'package:maktabati/data/models/sub_bab.dart';
import 'package:maktabati/data/models/content_block.dart';

class KitabParser {
  final String raw;
  late String title;
  late String author;
  final List<Bab> babs = [];

  KitabParser(this.raw) {
    _parse();
  }

  void _parse() {
    final lines = raw.split('\n').where((l) => l.trim().isNotEmpty).toList();
    if (lines.isEmpty) return;
    title = lines[0].trim();
    if (lines.length > 1 && lines[1].trim().startsWith('AUTHOR:')) {
      author = lines[1].substring(7).trim();
    } else {
      author = '';
    }
    int idx = 2;
    if (idx < lines.length && lines[idx].trim() == '===') idx++;

    Bab? currentBab;
    SubBab? currentSubBab;
    ContentBlock? currentBlock;

    void saveBlock() {
      if (currentBlock != null && currentSubBab != null) {
        currentSubBab.contents ??= [];
        currentSubBab.contents!.add(currentBlock!);
      }
    }

    while (idx < lines.length) {
      String line = lines[idx].trim();
      if (line.startsWith('= ') && !line.startsWith('== ')) {
        saveBlock();
        currentBab = Bab(
          id: DateTime.now().millisecondsSinceEpoch,
          title: line.substring(2),
        );
        babs.add(currentBab!);
        currentSubBab = null;
      } else if (line.startsWith('== ')) {
        saveBlock();
        currentSubBab = SubBab(
          id: DateTime.now().millisecondsSinceEpoch,
          title: line.substring(3),
        );
        currentBab!.subBabs ??= [];
        currentBab!.subBabs!.add(currentSubBab!);
      } else if (line.startsWith('[MATAN]')) {
        saveBlock();
        currentBlock = ContentBlock(
          id: DateTime.now().millisecondsSinceEpoch,
          matan: _readBlock(lines, idx + 1),
          syarah: '',
          terjemah: '',
        );
        idx += currentBlock.matan.split('\n').length;
      } else if (line.startsWith('[SYARAH]') && currentBlock != null) {
        currentBlock.syarah = _readBlock(lines, idx + 1);
        idx += currentBlock.syarah.split('\n').length;
      } else if (line.startsWith('[TERJEMAH]') && currentBlock != null) {
        currentBlock.terjemah = _readBlock(lines, idx + 1);
        idx += currentBlock.terjemah.split('\n').length;
      }
      idx++;
    }
    saveBlock();
  }

  String _readBlock(List<String> lines, int start) {
    final buffer = StringBuffer();
    for (int i = start; i < lines.length; i++) {
      final line = lines[i].trim();
      if (line.startsWith('[') || line.startsWith('---') || line.startsWith('= ')) {
        break;
      }
      buffer.writeln(line);
    }
    return buffer.toString().trim();
  }
}