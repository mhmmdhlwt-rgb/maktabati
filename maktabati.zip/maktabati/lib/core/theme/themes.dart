import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class AppThemes {
  static ThemeData creamLight() => _lightBase(AppColors.creamBg, AppColors.creamText, AppColors.creamSurface, AppColors.creamAccent);
  static ThemeData creamDark() => _darkBase(AppColors.creamBg, AppColors.creamText, AppColors.creamSurface, AppColors.creamAccent);

  static ThemeData emeraldLight() => _lightBase(AppColors.emeraldBg, AppColors.emeraldText, AppColors.emeraldSurface, AppColors.emeraldAccent);
  static ThemeData emeraldDark() => _darkBase(AppColors.emeraldBg, AppColors.emeraldText, AppColors.emeraldSurface, AppColors.emeraldAccent);

  static ThemeData midnightLight() => _lightBase(AppColors.midnightBg, AppColors.midnightText, AppColors.midnightSurface, AppColors.midnightAccent);
  static ThemeData midnightDark() => _darkBase(AppColors.midnightBg, AppColors.midnightText, AppColors.midnightSurface, AppColors.midnightAccent);

  static ThemeData sepiaLight() => _lightBase(AppColors.sepiaBg, AppColors.sepiaText, AppColors.sepiaSurface, AppColors.sepiaAccent);
  static ThemeData sepiaDark() => _darkBase(AppColors.sepiaBg, AppColors.sepiaText, AppColors.sepiaSurface, AppColors.sepiaAccent);

  static ThemeData whiteLight() => _lightBase(AppColors.whiteBg, AppColors.whiteText, AppColors.whiteSurface, AppColors.whiteAccent);
  static ThemeData whiteDark() => _darkBase(AppColors.whiteBg, AppColors.whiteText, AppColors.whiteSurface, AppColors.whiteAccent);

  static ThemeData _lightBase(Color bg, Color onBg, Color surface, Color accent) {
    return ThemeData(
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.light(
        surface: surface,
        onSurface: onBg,
        primary: accent,
        onPrimary: onBg,
        secondary: accent,
        onSecondary: onBg,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: bg,
        foregroundColor: onBg,
        elevation: 0,
      ),
      cardTheme: CardTheme(
        color: surface,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
      ),
      textTheme: TextTheme(
        bodyLarge: TextStyle(color: onBg),
        bodyMedium: TextStyle(color: onBg),
        titleLarge: TextStyle(color: onBg),
      ),
      fontFamily: 'Inter',
    );
  }

  static ThemeData _darkBase(Color bg, Color onBg, Color surface, Color accent) {
    return ThemeData(
      scaffoldBackgroundColor: bg,
      brightness: Brightness.dark,
      colorScheme: ColorScheme.dark(
        surface: surface,
        onSurface: onBg,
        primary: accent,
        onPrimary: onBg,
        secondary: accent,
        onSecondary: onBg,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: bg,
        foregroundColor: onBg,
        elevation: 0,
      ),
      cardTheme: CardTheme(
        color: surface,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
      ),
      textTheme: TextTheme(
        bodyLarge: TextStyle(color: onBg),
        bodyMedium: TextStyle(color: onBg),
        titleLarge: TextStyle(color: onBg),
      ),
      fontFamily: 'Inter',
    );
  }
}