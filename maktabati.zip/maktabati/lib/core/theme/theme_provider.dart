import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:riverpod/riverpod.dart';
import 'themes.dart';

enum AppThemeEnum { cream, emerald, midnight, sepia, white }

final themeModeProvider = StateProvider<ThemeMode>((ref) => ThemeMode.light);
final themeEnumProvider = StateProvider<AppThemeEnum>((ref) => AppThemeEnum.cream);
final localeProvider = StateProvider<Locale>((ref) => const Locale('en'));

final appThemeProvider = Provider<AppThemesData>((ref) {
  final themeEnum = ref.watch(themeEnumProvider);
  switch (themeEnum) {
    case AppThemeEnum.cream:
      return AppThemesData(AppThemes.creamLight(), AppThemes.creamDark());
    case AppThemeEnum.emerald:
      return AppThemesData(AppThemes.emeraldLight(), AppThemes.emeraldDark());
    case AppThemeEnum.midnight:
      return AppThemesData(AppThemes.midnightLight(), AppThemes.midnightDark());
    case AppThemeEnum.sepia:
      return AppThemesData(AppThemes.sepiaLight(), AppThemes.sepiaDark());
    case AppThemeEnum.white:
      return AppThemesData(AppThemes.whiteLight(), AppThemes.whiteDark());
  }
});

class AppThemesData {
  final ThemeData lightTheme;
  final ThemeData darkTheme;
  AppThemesData(this.lightTheme, this.darkTheme);
}

// Load/Save from Hive box 'settings'
Future<void> loadSettings(WidgetRef ref) async {
  final settingsBox = Hive.box('settings');
  final themeModeStr = settingsBox.get('themeMode', defaultValue: 'light');
  final themeEnumStr = settingsBox.get('theme', defaultValue: 'cream');
  final localeStr = settingsBox.get('locale', defaultValue: 'en');
  ref.read(themeModeProvider.notifier).state = themeModeStr == 'dark' ? ThemeMode.dark : ThemeMode.light;
  ref.read(themeEnumProvider.notifier).state = AppThemeEnum.values.firstWhere((e) => e.name == themeEnumStr);
  ref.read(localeProvider.notifier).state = Locale(localeStr);
}

Future<void> saveThemeMode(WidgetRef ref, ThemeMode mode) async {
  await Hive.box('settings').put('themeMode', mode == ThemeMode.dark ? 'dark' : 'light');
  ref.read(themeModeProvider.notifier).state = mode;
}

Future<void> saveThemeEnum(WidgetRef ref, AppThemeEnum theme) async {
  await Hive.box('settings').put('theme', theme.name);
  ref.read(themeEnumProvider.notifier).state = theme;
}

Future<void> saveLocale(WidgetRef ref, Locale locale) async {
  await Hive.box('settings').put('locale', locale.languageCode);
  ref.read(localeProvider.notifier).state = locale;
}