import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'app.dart';
import 'data/models/kitab_metadata.dart';
import 'data/models/bab.dart';
import 'data/models/sub_bab.dart';
import 'data/models/content_block.dart';
import 'data/models/reading_position.dart';
import 'l10n/app_localizations.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Inisialisasi Hive
  await Hive.initFlutter();
  // Register adapters (otomatis jika menggunakan hive_generator, tapi kita manual)
  Hive.registerAdapter(KitabMetadataAdapter());
  Hive.registerAdapter(BabAdapter());
  Hive.registerAdapter(SubBabAdapter());
  Hive.registerAdapter(ContentBlockAdapter());
  Hive.registerAdapter(ReadingPositionAdapter());
  // Buka box penting
  await Hive.openBox('settings');
  await Hive.openBox('kitabs_metadata');
  // Buat 10 box kitab kosong jika belum ada
  final metadataBox = Hive.box('kitabs_metadata');
  if (metadataBox.isEmpty) {
    for (int i = 1; i <= 10; i++) {
      final boxName = 'kitab_$i';
      await Hive.openBox(boxName);
      metadataBox.add(KitabMetadata(
        id: i,
        title: 'Kitab $i',
        author: '',
        boxName: boxName,
        createdAt: DateTime.now(),
        lastOpened: DateTime.now(),
        totalBab: 0,
      ));
    }
  }
  runApp(const ProviderScope(child: MaktabatiApp()));
}