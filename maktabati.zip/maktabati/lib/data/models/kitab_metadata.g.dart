import 'package:hive/hive.dart';
import 'kitab_metadata.dart';

class KitabMetadataAdapter extends TypeAdapter<KitabMetadata> {
  @override
  final int typeId = 0;

  @override
  KitabMetadata read(BinaryReader reader) {
    return KitabMetadata(
      id: reader.readInt(),
      title: reader.readString(),
      author: reader.readString(),
      coverBase64: reader.readStringOrNull(),
      createdAt: DateTime.fromMillisecondsSinceEpoch(reader.readInt()),
      lastOpened: DateTime.fromMillisecondsSinceEpoch(reader.readInt()),
      totalBab: reader.readInt(),
      boxName: reader.readString(),
    );
  }

  @override
  void write(BinaryWriter writer, KitabMetadata obj) {
    writer.writeInt(obj.id);
    writer.writeString(obj.title);
    writer.writeString(obj.author);
    writer.writeStringOrNull(obj.coverBase64);
    writer.writeInt(obj.createdAt.millisecondsSinceEpoch);
    writer.writeInt(obj.lastOpened.millisecondsSinceEpoch);
    writer.writeInt(obj.totalBab);
    writer.writeString(obj.boxName);
  }
}