import 'package:hive/hive.dart';
import 'bab.dart';
import 'sub_bab.dart';

class BabAdapter extends TypeAdapter<Bab> {
  @override
  final int typeId = 1;

  @override
  Bab read(BinaryReader reader) {
    return Bab(
      id: reader.readInt(),
      title: reader.readString(),
    )..subBabs = reader.readList().cast<SubBab?>().whereType<SubBab>().toList();
  }

  @override
  void write(BinaryWriter writer, Bab obj) {
    writer.writeInt(obj.id);
    writer.writeString(obj.title);
    writer.writeList(obj.subBabs ?? []);
  }
}