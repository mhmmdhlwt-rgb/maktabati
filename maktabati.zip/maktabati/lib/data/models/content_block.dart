import 'package:hive/hive.dart';
part 'content_block.g.dart';

@HiveType(typeId: 3)
class ContentBlock extends HiveObject {
  @HiveField(0)
  int id;
  @HiveField(1)
  String matan;
  @HiveField(2)
  String syarah;
  @HiveField(3)
  String terjemah;
  @HiveField(4)
  String? notes;
  @HiveField(5)
  List<String>? imagesBase64;
  @HiveField(6)
  List<String>? tags;

  ContentBlock({
    required this.id,
    required this.matan,
    required this.syarah,
    required this.terjemah,
    this.notes,
    this.imagesBase64,
    this.tags,
  });
}