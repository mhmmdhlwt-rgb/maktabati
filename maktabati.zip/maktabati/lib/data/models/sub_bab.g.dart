import 'package:hive/hive.dart';
import 'sub_bab.dart';
import 'content_block.dart';

class SubBabAdapter extends TypeAdapter<SubBab> {
  @override
  final int typeId = 2;

  @override
  SubBab read(BinaryReader reader) {
    return SubBab(
      id: reader.readInt(),
      title: reader.readString(),
    )..contents = reader.readList().cast<ContentBlock?>().whereType<ContentBlock>().toList();
  }

  @override
  void write(BinaryWriter writer, SubBab obj) {
    writer.writeInt(obj.id);
    writer.writeString(obj.title);
    writer.writeList(obj.contents ?? []);
  }
}