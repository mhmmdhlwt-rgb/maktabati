import 'package:hive/hive.dart';
import 'content_block.dart';

class ContentBlockAdapter extends TypeAdapter<ContentBlock> {
  @override
  final int typeId = 3;

  @override
  ContentBlock read(BinaryReader reader) {
    return ContentBlock(
      id: reader.readInt(),
      matan: reader.readString(),
      syarah: reader.readString(),
      terjemah: reader.readString(),
      notes: reader.readStringOrNull(),
      imagesBase64: reader.readList().cast<String?>().whereType<String>().toList(),
      tags: reader.readList().cast<String?>().whereType<String>().toList(),
    );
  }

  @override
  void write(BinaryWriter writer, ContentBlock obj) {
    writer.writeInt(obj.id);
    writer.writeString(obj.matan);
    writer.writeString(obj.syarah);
    writer.writeString(obj.terjemah);
    writer.writeStringOrNull(obj.notes);
    writer.writeList(obj.imagesBase64 ?? []);
    writer.writeList(obj.tags ?? []);
  }
}