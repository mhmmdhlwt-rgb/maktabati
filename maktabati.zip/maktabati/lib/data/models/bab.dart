import 'package:hive/hive.dart';
import 'sub_bab.dart';
part 'bab.g.dart';

@HiveType(typeId: 1)
class Bab extends HiveObject {
  @HiveField(0)
  int id;
  @HiveField(1)
  String title;
  @HiveField(2)
  List<SubBab>? subBabs;

  Bab({required this.id, required this.title, this.subBabs});
}