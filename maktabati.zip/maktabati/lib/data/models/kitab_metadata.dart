import 'package:hive/hive.dart';
part 'kitab_metadata.g.dart';

@HiveType(typeId: 0)
class KitabMetadata extends HiveObject {
  @HiveField(0)
  int id;
  @HiveField(1)
  String title;
  @HiveField(2)
  String author;
  @HiveField(3)
  String? coverBase64;
  @HiveField(4)
  DateTime createdAt;
  @HiveField(5)
  DateTime lastOpened;
  @HiveField(6)
  int totalBab;
  @HiveField(7)
  String boxName;

  KitabMetadata({
    required this.id,
    required this.title,
    required this.author,
    this.coverBase64,
    required this.createdAt,
    required this.lastOpened,
    required this.totalBab,
    required this.boxName,
  });
}