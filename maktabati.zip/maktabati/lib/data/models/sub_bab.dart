import 'package:hive/hive.dart';
import 'content_block.dart';
part 'sub_bab.g.dart';

@HiveType(typeId: 2)
class SubBab extends HiveObject {
  @HiveField(0)
  int id;
  @HiveField(1)
  String title;
  @HiveField(2)
  List<ContentBlock>? contents;

  SubBab({required this.id, required this.title, this.contents});
}