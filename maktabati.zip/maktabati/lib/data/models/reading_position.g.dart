import 'package:hive/hive.dart';
import 'reading_position.dart';

class ReadingPositionAdapter extends TypeAdapter<ReadingPosition> {
  @override
  final int typeId = 4;

  @override
  ReadingPosition read(BinaryReader reader) {
    return ReadingPosition(
      kitabId: reader.readInt(),
      babIndex: reader.readInt(),
      subBabIndex: reader.readInt(),
      contentIndex: reader.readInt(),
    );
  }

  @override
  void write(BinaryWriter writer, ReadingPosition obj) {
    writer.writeInt(obj.kitabId);
    writer.writeInt(obj.babIndex);
    writer.writeInt(obj.subBabIndex);
    writer.writeInt(obj.contentIndex);
  }
}