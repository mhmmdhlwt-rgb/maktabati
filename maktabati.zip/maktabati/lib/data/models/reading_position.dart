import 'package:hive/hive.dart';
part 'reading_position.g.dart';

@HiveType(typeId: 4)
class ReadingPosition extends HiveObject {
  @HiveField(0)
  int kitabId;
  @HiveField(1)
  int babIndex;
  @HiveField(2)
  int subBabIndex;
  @HiveField(3)
  int contentIndex;

  ReadingPosition({
    required this.kitabId,
    this.babIndex = 0,
    this.subBabIndex = 0,
    this.contentIndex = 0,
  });
}