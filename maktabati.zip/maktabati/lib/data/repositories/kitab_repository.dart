import 'package:maktabati/data/hive/hive_service.dart';
import 'package:maktabati/data/models/kitab_metadata.dart';
import 'package:maktabati/data/models/bab.dart';
import 'package:maktabati/data/models/reading_position.dart';
import 'package:maktabati/core/utils/parser.dart';
import 'package:maktabati/core/utils/exporter.dart';

class KitabRepository {
  static List<KitabMetadata> getAllKitabs() {
    return HiveService.metadataBox.values.toList();
  }

  static KitabMetadata? getKitabById(int id) {
    return HiveService.metadataBox.values.firstWhere((k) => k.id == id);
  }

  static Future<void> importFromRawText(String rawText, int targetKitabId) async {
    final parser = KitabParser(rawText);
    final metaBox = HiveService.metadataBox;
    final meta = metaBox.values.firstWhere((k) => k.id == targetKitabId);
    meta.title = parser.title;
    meta.author = parser.author;
    meta.totalBab = parser.babs.length;
    await meta.save();

    final box = await HiveService.openKitabBox(targetKitabId);
    await box.clear();
    for (var bab in parser.babs) {
      await box.add(bab);
    }
  }

  static Future<List<Bab>> getBabs(int kitabId) async {
    final box = await HiveService.openKitabBox(kitabId);
    return box.values.toList();
  }

  static Future<void> saveBabs(int kitabId, List<Bab> babs) async {
    final box = await HiveService.openKitabBox(kitabId);
    await box.clear();
    for (var bab in babs) {
      await box.add(bab);
    }
    final meta = getKitabById(kitabId);
    if (meta != null) {
      meta.totalBab = babs.length;
      await meta.save();
    }
  }

  static String exportKitab(int kitabId) {
    final meta = getKitabById(kitabId);
    if (meta == null) return '';
    final babs = HiveService.getKitabBox(kitabId)?.values.toList() ?? [];
    return KitabExporter.export(title: meta.title, author: meta.author, babs: babs);
  }

  static void updateCover(int kitabId, String base64) async {
    final meta = getKitabById(kitabId);
    if (meta != null) {
      meta.coverBase64 = base64;
      await meta.save();
    }
  }
}