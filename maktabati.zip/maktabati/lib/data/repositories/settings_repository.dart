import 'package:hive_flutter/hive_flutter.dart';

class SettingsRepository {
  static final Box _box = Hive.box('settings');

  static String get ownerName => _box.get('ownerName', defaultValue: '');
  static set ownerName(String value) => _box.put('ownerName', value);

  static double get arabicFontSize => _box.get('arabicFontSize', defaultValue: 24.0);
  static set arabicFontSize(double value) => _box.put('arabicFontSize', value);

  static double get latinFontSize => _box.get('latinFontSize', defaultValue: 14.0);
  static set latinFontSize(double value) => _box.put('latinFontSize', value);

  static double get lineSpacing => _box.get('lineSpacing', defaultValue: 1.8);
  static set lineSpacing(double value) => _box.put('lineSpacing', value);

  static double get paragraphSpacing => _box.get('paragraphSpacing', defaultValue: 12.0);
  static set paragraphSpacing(double value) => _box.put('paragraphSpacing', value);

  static String get arabicFontFamily => _box.get('arabicFontFamily', defaultValue: 'Amiri');
  static set arabicFontFamily(String value) => _box.put('arabicFontFamily', value);

  static bool get showHarakat => _box.get('showHarakat', defaultValue: true);
  static set showHarakat(bool value) => _box.put('showHarakat', value);

  static String get readingMode => _box.get('readingMode', defaultValue: 'study');
  static set readingMode(String value) => _box.put('readingMode', value);

  static int get shelfColumns => _box.get('shelfColumns', defaultValue: 2);
  static set shelfColumns(int value) => _box.put('shelfColumns', value);
}