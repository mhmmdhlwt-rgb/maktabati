import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:maktabati/data/models/kitab_metadata.dart';
import 'package:universal_html/html.dart' as html;
import 'package:file_saver/file_saver.dart';
import 'hive_service.dart';
import '../models/bab.dart';

class BackupManager {
  static Future<String> exportFullBackup() async {
    final metaList = HiveService.metadataBox.values.toList();
    final kitabsData = <Map<String, dynamic>>[];
    for (var meta in metaList) {
      final box = HiveService.getKitabBox(meta.id);
      if (box != null) {
        final babs = box.values.toList();
        kitabsData.add({
          'kitabId': meta.id,
          'babs': babs.map((b) => _babToJson(b)).toList(),
        });
      }
    }
    final backup = {
      'type': 'full_backup',
      'version': 1,
      'metadata': metaList.map((m) => _metaToJson(m)).toList(),
      'kitabs': kitabsData,
    };
    return jsonEncode(backup);
  }

  static Future<String> exportKitabBackup(KitabMetadata meta) async {
    final box = HiveService.getKitabBox(meta.id);
    if (box == null) return '';
    final babs = box.values.toList();
    final data = {
      'type': 'kitab_backup',
      'version': 1,
      'metadata': _metaToJson(meta),
      'babs': babs.map((b) => _babToJson(b)).toList(),
    };
    return jsonEncode(data);
  }

  static Future<void> restoreFromJson(String jsonStr) async {
    final data = jsonDecode(jsonStr);
    if (data['type'] == 'full_backup') {
      // Clear existing and restore
      await HiveService.metadataBox.clear();
      for (var m in data['metadata']) {
        final meta = KitabMetadata(
          id: m['id'],
          title: m['title'],
          author: m['author'],
          coverBase64: m['coverBase64'],
          createdAt: DateTime.parse(m['createdAt']),
          lastOpened: DateTime.parse(m['lastOpened']),
          totalBab: m['totalBab'],
          boxName: m['boxName'],
        );
        await HiveService.metadataBox.add(meta);
        // Restore kitab box
        final kitabData = data['kitabs'].firstWhere((k) => k['kitabId'] == meta.id, orElse: () => null);
        if (kitabData != null) {
          final box = await HiveService.openKitabBox(meta.id);
          await box.clear();
          for (var b in kitabData['babs']) {
            box.add(Bab.fromJson(b));
          }
        }
      }
    }
    // Handle partial kitab restore similarly...
  }

  static void saveToFile(String content, String fileName) {
    final bytes = utf8.encode(content);
    final blob = html.Blob([bytes]);
    final url = html.Url.createObjectUrlFromBlob(blob);
    final anchor = html.AnchorElement(href: url)
      ..setAttribute('download', fileName)
      ..click();
    html.Url.revokeObjectUrl(url);
  }

  static Map<String, dynamic> _metaToJson(KitabMetadata m) => {
    'id': m.id,
    'title': m.title,
    'author': m.author,
    'coverBase64': m.coverBase64,
    'createdAt': m.createdAt.toIso8601String(),
    'lastOpened': m.lastOpened.toIso8601String(),
    'totalBab': m.totalBab,
    'boxName': m.boxName,
  };

  static Map<String, dynamic> _babToJson(Bab b) => {
    'id': b.id,
    'title': b.title,
    'subBabs': b.subBabs?.map((s) => {
      'id': s.id,
      'title': s.title,
      'contents': s.contents?.map((c) => {
        'id': c.id,
        'matan': c.matan,
        'syarah': c.syarah,
        'terjemah': c.terjemah,
        'notes': c.notes,
        'imagesBase64': c.imagesBase64,
        'tags': c.tags,
      }).toList(),
    }).toList(),
  };
}

extension BabFromJson on Bab {
  static Bab fromJson(Map<String, dynamic> json) {
    return Bab(
      id: json['id'],
      title: json['title'],
      subBabs: (json['subBabs'] as List?)?.map((s) => SubBab.fromJson(s)).toList(),
    );
  }
}

extension SubBabFromJson on SubBab {
  static SubBab fromJson(Map<String, dynamic> json) {
    return SubBab(
      id: json['id'],
      title: json['title'],
      contents: (json['contents'] as List?)?.map((c) => ContentBlock.fromJson(c)).toList(),
    );
  }
}

extension ContentBlockFromJson on ContentBlock {
  static ContentBlock fromJson(Map<String, dynamic> json) {
    return ContentBlock(
      id: json['id'],
      matan: json['matan'],
      syarah: json['syarah'],
      terjemah: json['terjemah'],
      notes: json['notes'],
      imagesBase64: List<String>.from(json['imagesBase64'] ?? []),
      tags: List<String>.from(json['tags'] ?? []),
    );
  }
}