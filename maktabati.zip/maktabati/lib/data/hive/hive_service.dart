import 'package:hive_flutter/hive_flutter.dart';
import 'package:maktabati/data/models/kitab_metadata.dart';
import 'package:maktabati/data/models/bab.dart';
import 'package:maktabati/data/models/sub_bab.dart';
import 'package:maktabati/data/models/content_block.dart';
import 'package:maktabati/data/models/reading_position.dart';

class HiveService {
  static Box<KitabMetadata> get metadataBox => Hive.box<KitabMetadata>('kitabs_metadata');
  static Box get settingsBox => Hive.box('settings');

  static Box<Bab>? getKitabBox(int kitabId) {
    if (Hive.isBoxOpen('kitab_$kitabId')) {
      return Hive.box<Bab>('kitab_$kitabId');
    }
    return null;
  }

  static Future<Box<Bab>> openKitabBox(int kitabId) async {
    if (!Hive.isBoxOpen('kitab_$kitabId')) {
      return await Hive.openBox<Bab>('kitab_$kitabId');
    }
    return Hive.box<Bab>('kitab_$kitabId');
  }

  static Future<void> saveReadingPosition(ReadingPosition pos) async {
    final box = Hive.box<ReadingPosition>('reading_positions');
    await box.put(pos.kitabId, pos);
  }

  static ReadingPosition? getReadingPosition(int kitabId) {
    final box = Hive.box<ReadingPosition>('reading_positions');
    return box.get(kitabId);
  }
}