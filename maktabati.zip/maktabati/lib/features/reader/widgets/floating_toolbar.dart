import 'package:flutter/material.dart';
import 'package:maktabati/data/repositories/kitab_repository.dart';
import 'package:maktabati/features/reader/widgets/search_overlay_reader.dart';

class FloatingToolbar extends StatelessWidget {
  final int kitabId;
  final VoidCallback onToggleTranslation;
  const FloatingToolbar({super.key, required this.kitabId, required this.onToggleTranslation});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: const ColorFilter.matrix(<double>[
          1,0,0,0,0,
          0,1,0,0,0,
          0,0,1,0,0,
          0,0,0,0.4,0,
        ]),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface.withOpacity(0.7),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(color: Colors.black12, blurRadius: 12, offset: Offset(0, 4)),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(icon: const Icon(Icons.bookmark_border), onPressed: () {}),
              IconButton(icon: const Icon(Icons.search), onPressed: () {
                showSearchOverlay(context, kitabId);
              }),
              IconButton(icon: const Icon(Icons.notes), onPressed: () {}),
              IconButton(icon: const Icon(Icons.text_fields), onPressed: onToggleTranslation),
              IconButton(icon: const Icon(Icons.palette), onPressed: () {}),
            ],
          ),
        ),
      ),
    );
  }

  void showSearchOverlay(BuildContext context, int kitabId) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => SearchOverlayReader(kitabId: kitabId)));
  }
}