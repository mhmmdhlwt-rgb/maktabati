import 'package:flutter/material.dart';

class TranslationToggle extends StatefulWidget {
  final Widget child;
  const TranslationToggle({super.key, required this.child});

  @override
  _TranslationToggleState createState() => _TranslationToggleState();
}

class _TranslationToggleState extends State<TranslationToggle> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InkWell(
          onTap: () => setState(() => _expanded = !_expanded),
          child: Row(
            children: [
              Icon(_expanded ? Icons.expand_less : Icons.expand_more, size: 20),
              const SizedBox(width: 4),
              Text(_expanded ? 'Hide Translation' : 'Show Translation',
                  style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
        AnimatedSize(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
          child: _expanded ? Padding(padding: const EdgeInsets.only(top: 8), child: widget.child) : const SizedBox.shrink(),
        ),
      ],
    );
  }
}