import 'package:flutter/material.dart';
import 'package:maktabati/core/utils/arabic_utils.dart';
import 'package:maktabati/data/repositories/kitab_repository.dart';
import 'package:maktabati/data/models/bab.dart';

class SearchOverlayReader extends StatefulWidget {
  final int kitabId;
  const SearchOverlayReader({super.key, required this.kitabId});

  @override
  _SearchOverlayReaderState createState() => _SearchOverlayReaderState();
}

class _SearchOverlayReaderState extends State<SearchOverlayReader> {
  final TextEditingController _controller = TextEditingController();
  List<SearchResult> results = [];
  late List<Bab> babs;

  @override
  void initState() {
    super.initState();
    babs = KitabRepository.getBabs(widget.kitabId) as List<Bab>;
  }

  void _search(String query) {
    if (query.isEmpty) {
      setState(() => results = []);
      return;
    }
    final normalizedQuery = ArabicUtils.normalizeForSearch(query);
    final tempResults = <SearchResult>[];
    for (var bab in babs) {
      for (var sub in bab.subBabs ?? []) {
        for (int i = 0; i < (sub.contents?.length ?? 0); i++) {
          final block = sub.contents![i];
          if (ArabicUtils.normalizeForSearch(block.matan).contains(normalizedQuery) ||
              ArabicUtils.normalizeForSearch(block.syarah).contains(normalizedQuery)) {
            tempResults.add(SearchResult(bab: bab.title, subBab: sub.title, contentIndex: i, snippet: block.matan));
          }
        }
      }
    }
    setState(() => results = tempResults);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Search in kitab...'),
          onChanged: _search,
        ),
      ),
      body: ListView.builder(
        itemCount: results.length,
        itemBuilder: (context, idx) {
          final res = results[idx];
          return ListTile(
            title: Text(res.snippet, maxLines: 2, overflow: TextOverflow.ellipsis),
            subtitle: Text('${res.bab} > ${res.subBab}'),
            onTap: () {
              Navigator.pop(context, res);
            },
          );
        },
      ),
    );
  }
}

class SearchResult {
  final String bab;
  final String subBab;
  final int contentIndex;
  final String snippet;
  SearchResult({required this.bab, required this.subBab, required this.contentIndex, required this.snippet});
}