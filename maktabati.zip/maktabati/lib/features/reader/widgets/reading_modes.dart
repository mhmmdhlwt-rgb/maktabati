import 'package:flutter/material.dart';
import 'package:maktabati/data/repositories/settings_repository.dart';

class ReadingModeSelector extends StatelessWidget {
  const ReadingModeSelector({super.key});

  @override
  Widget build(BuildContext context) {
    final current = SettingsRepository.readingMode;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _ModeChip(label: 'Matan', value: 'matan', current: current),
        _ModeChip(label: 'Study', value: 'study', current: current),
        _ModeChip(label: 'Teacher', value: 'teacher', current: current),
        _ModeChip(label: 'Compact', value: 'compact', current: current),
      ],
    );
  }
}

class _ModeChip extends StatelessWidget {
  final String label, value, current;
  const _ModeChip({required this.label, required this.value, required this.current});

  @override
  Widget build(BuildContext context) {
    final selected = value == current;
    return GestureDetector(
      onTap: () => SettingsRepository.readingMode = value,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? Theme.of(context).colorScheme.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Theme.of(context).colorScheme.primary),
        ),
        child: Text(label, style: TextStyle(color: selected ? Colors.white : null)),
      ),
    );
  }
}