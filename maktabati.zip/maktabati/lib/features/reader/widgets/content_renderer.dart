import 'package:flutter/material.dart';
import 'package:maktabati/data/models/sub_bab.dart';
import 'package:maktabati/core/utils/arabic_utils.dart';
import 'package:maktabati/data/repositories/settings_repository.dart';
import 'package:maktabati/core/constants/app_text_styles.dart';

class ContentRenderer extends StatelessWidget {
  final SubBab subBab;
  const ContentRenderer({super.key, required this.subBab});

  @override
  Widget build(BuildContext context) {
    if (subBab.contents == null || subBab.contents!.isEmpty) {
      return const Center(child: Text('No content'));
    }
    final showHarakat = SettingsRepository.showHarakat;
    final arabicFont = SettingsRepository.arabicFontFamily;
    final arabicSize = SettingsRepository.arabicFontSize;
    final latinSize = SettingsRepository.latinFontSize;
    final lineSpacing = SettingsRepository.lineSpacing;
    final readingMode = SettingsRepository.readingMode; // 'matan', 'study', etc.

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: subBab.contents!.length,
      itemBuilder: (context, index) {
        final block = subBab.contents![index];
        String matan = block.matan;
        String syarah = block.syarah;
        if (!showHarakat) {
          matan = ArabicUtils.removeDiacritics(matan);
          syarah = ArabicUtils.removeDiacritics(syarah);
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (readingMode != 'teacher') // teacher mode shows matan with syarah
              Text(
                matan,
                style: AppTextStyles.matan(context, fontFamily: arabicFont, fontSize: arabicSize).copyWith(height: lineSpacing),
                textDirection: TextDirection.rtl,
              ),
            if (readingMode == 'study' || readingMode == 'teacher')
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  syarah,
                  style: AppTextStyles.syarah(context, fontFamily: arabicFont, fontSize: arabicSize - 4).copyWith(height: lineSpacing),
                  textDirection: TextDirection.rtl,
                ),
              ),
            // Translation toggle would be here, initially collapsed
            const SizedBox(height: 24),
          ],
        );
      },
    );
  }
}