import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:maktabati/data/repositories/kitab_repository.dart';
import 'package:maktabati/data/repositories/settings_repository.dart';
import 'package:maktabati/data/models/bab.dart';
import 'package:maktabati/data/hive/hive_service.dart';
import 'widgets/content_renderer.dart';
import 'widgets/floating_toolbar.dart';

final currentBabIndexProvider = StateProvider<int>((ref) => 0);
final currentSubBabIndexProvider = StateProvider<int>((ref) => 0);

class ReaderPage extends ConsumerStatefulWidget {
  final int kitabId;
  final bool continueLast;
  const ReaderPage({super.key, required this.kitabId, this.continueLast = false});

  @override
  _ReaderPageState createState() => _ReaderPageState();
}

class _ReaderPageState extends ConsumerState<ReaderPage> {
  late Future<List<Bab>> _babsFuture;
  bool _toolbarVisible = true;

  @override
  void initState() {
    super.initState();
    _babsFuture = KitabRepository.getBabs(widget.kitabId);
    if (widget.continueLast) {
      final pos = HiveService.getReadingPosition(widget.kitabId);
      if (pos != null) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          ref.read(currentBabIndexProvider.notifier).state = pos.babIndex;
          ref.read(currentSubBabIndexProvider.notifier).state = pos.subBabIndex;
        });
      }
    }
  }

  void _toggleToolbar() {
    setState(() {
      _toolbarVisible = !_toolbarVisible;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: _toggleToolbar,
        child: Stack(
          children: [
            FutureBuilder<List<Bab>>(
              future: _babsFuture,
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                final babs = snapshot.data!;
                final babIdx = ref.watch(currentBabIndexProvider);
                final subIdx = ref.watch(currentSubBabIndexProvider);
                if (babIdx >= babs.length) return const Center(child: Text('No content'));
                final bab = babs[babIdx];
                final subBab = bab.subBabs != null && bab.subBabs!.isNotEmpty
                    ? bab.subBabs![subIdx.clamp(0, bab.subBabs!.length - 1)]
                    : null;
                return Column(
                  children: [
                    AppBar(
                      title: Text(bab.title),
                      automaticallyImplyLeading: false,
                    ),
                    Expanded(
                      child: subBab != null
                          ? ContentRenderer(subBab: subBab)
                          : const Center(child: Text('No subchapter')),
                    ),
                  ],
                );
              },
            ),
            if (_toolbarVisible)
              Positioned(
                bottom: 24,
                left: 24,
                right: 24,
                child: FloatingToolbar(
                  kitabId: widget.kitabId,
                  onToggleTranslation: () {
                    // Implement
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}