import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:maktabati/data/repositories/settings_repository.dart';
import 'package:maktabati/core/theme/theme_provider.dart';
import 'package:maktabati/data/hive/backup_manager.dart';
import 'package:maktabati/data/repositories/kitab_repository.dart';

class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeEnum = ref.watch(themeEnumProvider);
    final locale = ref.watch(localeProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Owner Name', style: Theme.of(context).textTheme.titleMedium),
          TextField(
            controller: TextEditingController(text: SettingsRepository.ownerName),
            onChanged: (v) => SettingsRepository.ownerName = v,
          ),
          const SizedBox(height: 16),
          Text('Theme', style: Theme.of(context).textTheme.titleMedium),
          DropdownButton<AppThemeEnum>(
            value: themeEnum,
            onChanged: (val) {
              if (val != null) {
                ref.read(themeEnumProvider.notifier).state = val;
                saveThemeEnum(ref, val);
              }
            },
            items: AppThemeEnum.values.map((e) => DropdownMenuItem(value: e, child: Text(e.name))).toList(),
          ),
          const SizedBox(height: 16),
          Text('Language', style: Theme.of(context).textTheme.titleMedium),
          DropdownButton<Locale>(
            value: locale,
            onChanged: (val) {
              if (val != null) {
                ref.read(localeProvider.notifier).state = val;
                saveLocale(ref, val);
              }
            },
            items: const [
              DropdownMenuItem(value: Locale('en'), child: Text('English')),
              DropdownMenuItem(value: Locale('ar'), child: Text('العربية')),
            ],
          ),
          const SizedBox(height: 16),
          Text('Arabic Font', style: Theme.of(context).textTheme.titleMedium),
          DropdownButton<String>(
            value: SettingsRepository.arabicFontFamily,
            onChanged: (val) {
              if (val != null) SettingsRepository.arabicFontFamily = val;
            },
            items: ['Amiri', 'ScheherazadeNew', 'NotoNaskhArabic', 'Cairo', 'Lateef', 'ReemKufi', 'IBMPlexSansArabic']
                .map((f) => DropdownMenuItem(value: f, child: Text(f))).toList(),
          ),
          // Add sliders for sizes, line spacing, etc.
          const SizedBox(height: 16),
          Text('Shelf Columns', style: Theme.of(context).textTheme.titleMedium),
          Slider(
            value: SettingsRepository.shelfColumns.toDouble(),
            min: 1,
            max: 3,
            divisions: 2,
            onChanged: (v) => SettingsRepository.shelfColumns = v.toInt(),
            label: SettingsRepository.shelfColumns.toString(),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            icon: const Icon(Icons.backup),
            label: const Text('Backup All'),
            onPressed: () async {
              final json = await BackupManager.exportFullBackup();
              BackupManager.saveToFile(json, 'maktabati_backup.json');
            },
          ),
          ElevatedButton.icon(
            icon: const Icon(Icons.restore),
            label: const Text('Restore'),
            onPressed: () {
              // File picker web: use universal_html to create input element, read file, pass to restore.
            },
          ),
        ],
      ),
    );
  }
}