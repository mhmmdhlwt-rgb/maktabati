import 'package:flutter/material.dart';
import 'package:maktabati/data/repositories/kitab_repository.dart';
import 'package:maktabati/data/models/bab.dart';
import 'package:maktabati/data/models/sub_bab.dart';
import 'widgets/bab_list.dart';

class EditorPage extends StatefulWidget {
  final int kitabId;
  const EditorPage({super.key, required this.kitabId});

  @override
  _EditorPageState createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  late List<Bab> _babs;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    _babs = await KitabRepository.getBabs(widget.kitabId);
    setState(() => _loading = false);
  }

  Future<void> _save() async {
    await KitabRepository.saveBabs(widget.kitabId, _babs);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Editor'),
        actions: [
          IconButton(icon: const Icon(Icons.save), onPressed: _save),
          IconButton(icon: const Icon(Icons.add), onPressed: _addBab),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : BabList(babs: _babs, onUpdate: () => setState(() {})),
    );
  }

  void _addBab() {
    final newBab = Bab(id: DateTime.now().millisecondsSinceEpoch, title: 'New Chapter');
    _babs.add(newBab);
    setState(() {});
  }
}