import 'package:flutter/material.dart';
import 'package:maktabati/data/models/sub_bab.dart';
import 'package:maktabati/data/models/content_block.dart';

class ContentForm extends StatefulWidget {
  final SubBab subBab;
  const ContentForm({super.key, required this.subBab});

  @override
  _ContentFormState createState() => _ContentFormState();
}

class _ContentFormState extends State<ContentForm> {
  late List<ContentBlock> blocks;

  @override
  void initState() {
    super.initState();
    blocks = List.from(widget.subBab.contents ?? []);
  }

  void _addBlock() {
    blocks.add(ContentBlock(
      id: DateTime.now().millisecondsSinceEpoch,
      matan: '',
      syarah: '',
      terjemah: '',
    ));
    setState(() {});
  }

  void _save() {
    widget.subBab.contents = blocks;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Content'),
        actions: [IconButton(icon: const Icon(Icons.save), onPressed: _save)],
      ),
      body: ListView.builder(
        itemCount: blocks.length,
        itemBuilder: (context, index) {
          final block = blocks[index];
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  TextField(
                    decoration: const InputDecoration(labelText: 'Matan'),
                    controller: TextEditingController(text: block.matan),
                    onChanged: (v) => block.matan = v,
                    maxLines: 3,
                  ),
                  TextField(
                    decoration: const InputDecoration(labelText: 'Syarah'),
                    controller: TextEditingController(text: block.syarah),
                    onChanged: (v) => block.syarah = v,
                    maxLines: 5,
                  ),
                  TextField(
                    decoration: const InputDecoration(labelText: 'Terjemah'),
                    controller: TextEditingController(text: block.terjemah),
                    onChanged: (v) => block.terjemah = v,
                    maxLines: 3,
                  ),
                  IconButton(icon: const Icon(Icons.delete), onPressed: () {
                    blocks.removeAt(index);
                    setState(() {});
                  }),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(onPressed: _addBlock, child: const Icon(Icons.add)),
    );
  }
}