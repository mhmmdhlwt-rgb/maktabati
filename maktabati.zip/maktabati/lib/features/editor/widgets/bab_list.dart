import 'package:flutter/material.dart';
import 'package:maktabati/data/models/bab.dart';
import 'package:maktabati/data/models/sub_bab.dart';
import 'content_form.dart';

class BabList extends StatelessWidget {
  final List<Bab> babs;
  final VoidCallback onUpdate;
  const BabList({super.key, required this.babs, required this.onUpdate});

  @override
  Widget build(BuildContext context) {
    return ReorderableListView.builder(
      itemCount: babs.length,
      onReorder: (oldIndex, newIndex) {
        if (newIndex > oldIndex) newIndex--;
        final item = babs.removeAt(oldIndex);
        babs.insert(newIndex, item);
        onUpdate();
      },
      itemBuilder: (context, index) {
        final bab = babs[index];
        return Card(
          key: ValueKey(bab.id),
          child: ExpansionTile(
            title: Text(bab.title),
            subtitle: Text('${bab.subBabs?.length ?? 0} subchapters'),
            children: [
              ...?bab.subBabs?.map((sub) => ListTile(
                title: Text(sub.title),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(icon: const Icon(Icons.edit), onPressed: () => _editContent(context, sub)),
                    IconButton(icon: const Icon(Icons.delete), onPressed: () {
                      bab.subBabs!.remove(sub);
                      onUpdate();
                    }),
                  ],
                ),
              )).toList(),
              TextButton.icon(
                icon: const Icon(Icons.add),
                label: const Text('Add Subchapter'),
                onPressed: () {
                  final newSub = SubBab(id: DateTime.now().millisecondsSinceEpoch, title: 'New Subchapter');
                  bab.subBabs ??= [];
                  bab.subBabs!.add(newSub);
                  onUpdate();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _editContent(BuildContext context, SubBab subBab) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ContentForm(subBab: subBab)));
  }
}