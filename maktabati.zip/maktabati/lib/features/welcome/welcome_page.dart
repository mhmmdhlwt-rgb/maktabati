import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../l10n/app_localizations.dart';
import '../dashboard/dashboard_page.dart';

class WelcomePage extends ConsumerWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final loc = AppLocalizations.of(context);
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'مكتبتي',
                style: TextStyle(fontSize: 48, fontFamily: 'Amiri', fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              Text(
                loc.welcomeMessage,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontSize: 18),
              ),
              const SizedBox(height: 48),
              ElevatedButton(
                onPressed: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const DashboardPage()),
                ),
                child: Text(loc.enterLibrary),
              ),
            ],
          ),
        ),
      ),
    );
  }
}