import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:maktabati/data/models/kitab_metadata.dart';
import 'kitab_detail_modal.dart';

class KitabTile3D extends StatelessWidget {
  final KitabMetadata kitab;
  const KitabTile3D({super.key, required this.kitab});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => showKitabDetailModal(context, kitab),
      child: Transform(
        transform: Matrix4.identity()
          ..setEntry(3, 2, 0.001)
          ..rotateX(-0.05),
        alignment: Alignment.bottomCenter,
        child: Column(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(color: Colors.black26, blurRadius: 12, offset: Offset(0, 10)),
                  ],
                  borderRadius: BorderRadius.circular(4),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: kitab.coverBase64 != null
                      ? Image.memory(
                          base64Decode(kitab.coverBase64!),
                          fit: BoxFit.cover,
                        )
                      : Container(
                          color: const Color(0xFF8B5A2B),
                          child: Center(
                            child: Text(
                              kitab.title,
                              style: const TextStyle(fontFamily: 'Amiri', color: Colors.white70, fontSize: 18),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                ),
              ),
            ),
            const SizedBox(height: 4),
            Container(
              height: 10,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF8B5A2B), Color(0xFF5C3A21)]),
                borderRadius: BorderRadius.circular(2),
                boxShadow: [BoxShadow(color: Colors.black38, blurRadius: 4)],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              kitab.title,
              style: Theme.of(context).textTheme.titleMedium,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              kitab.author,
              style: Theme.of(context).textTheme.bodySmall,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}