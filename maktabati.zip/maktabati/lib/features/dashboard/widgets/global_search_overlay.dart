import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:maktabati/data/repositories/kitab_repository.dart';
import 'package:maktabati/data/models/kitab_metadata.dart';

class GlobalSearchOverlay extends ConsumerStatefulWidget {
  const GlobalSearchOverlay({super.key});

  @override
  _GlobalSearchOverlayState createState() => _GlobalSearchOverlayState();
}

class _GlobalSearchOverlayState extends ConsumerState<GlobalSearchOverlay> {
  final TextEditingController _controller = TextEditingController();
  List<KitabMetadata> results = [];

  @override
  void initState() {
    super.initState();
    results = KitabRepository.getAllKitabs();
  }

  void _search(String query) {
    setState(() {
      results = KitabRepository.getAllKitabs().where((k) =>
          k.title.toLowerCase().contains(query.toLowerCase()) ||
          k.author.toLowerCase().contains(query.toLowerCase())).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      contentPadding: EdgeInsets.zero,
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _controller,
            autofocus: true,
            decoration: const InputDecoration(hintText: 'Search kitabs...', prefixIcon: Icon(Icons.search)),
            onChanged: _search,
          ),
          ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 300),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: results.length,
              itemBuilder: (context, index) => ListTile(
                title: Text(results[index].title),
                subtitle: Text(results[index].author),
                onTap: () {
                  Navigator.pop(context);
                  // Navigasi ke kitab, bisa langsung reader
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}