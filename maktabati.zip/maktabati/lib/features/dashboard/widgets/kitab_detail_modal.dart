import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:maktabati/data/models/kitab_metadata.dart';
import 'package:maktabati/features/reader/reader_page.dart';
import 'package:maktabati/data/hive/hive_service.dart';
import 'package:maktabati/data/repositories/kitab_repository.dart';
import 'package:maktabati/core/utils/image_compressor.dart';
import '../../../l10n/app_localizations.dart';

Future<void> showKitabDetailModal(BuildContext context, KitabMetadata kitab) {
  final loc = AppLocalizations.of(context);
  return showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => StatefulBuilder(
      builder: (context, setModalState) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.75,
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Cover + title
                if (kitab.coverBase64 != null)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.memory(
                      base64Decode(kitab.coverBase64!),
                      height: 200,
                      width: 150,
                      fit: BoxFit.cover,
                    ),
                  )
                else
                  Container(
                    height: 200,
                    width: 150,
                    decoration: BoxDecoration(
                      color: const Color(0xFF8B5A2B),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(child: Text(kitab.title, style: const TextStyle(color: Colors.white))),
                  ),
                const SizedBox(height: 16),
                Text(kitab.title, style: Theme.of(context).textTheme.headlineSmall),
                Text(kitab.author, style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 24),
                // Buttons
                ElevatedButton.icon(
                  icon: const Icon(Icons.play_arrow),
                  label: Text(loc.readFromBeginning),
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(builder: (_) => ReaderPage(kitabId: kitab.id)));
                  },
                ),
                const SizedBox(height: 8),
                if (HiveService.getReadingPosition(kitab.id) != null)
                  ElevatedButton.icon(
                    icon: const Icon(Icons.bookmark),
                    label: Text(loc.continueReading),
                    onPressed: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => ReaderPage(kitabId: kitab.id, continueLast: true)));
                    },
                  ),
                const SizedBox(height: 8),
                ElevatedButton.icon(
                  icon: const Icon(Icons.edit),
                  label: Text(loc.editKitab),
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(builder: (_) => EditorPage(kitabId: kitab.id)));
                  },
                ),
                const SizedBox(height: 8),
                ElevatedButton.icon(
                  icon: const Icon(Icons.image),
                  label: Text(loc.changeCover),
                  onPressed: () async {
                    final base64 = await ImageCompressor.pickAndCompress(maxWidth: 400, quality: 80);
                    if (base64 != null) {
                      KitabRepository.updateCover(kitab.id, base64);
                      setModalState(() {}); // refresh UI
                    }
                  },
                ),
              ],
            ),
          ),
        );
      },
    ),
  );
}