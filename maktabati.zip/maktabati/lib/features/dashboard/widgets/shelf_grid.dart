import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:maktabati/data/models/kitab_metadata.dart';
import 'package:maktabati/data/repositories/settings_repository.dart';
import 'kitab_tile_3d.dart';

class ShelfGrid extends ConsumerWidget {
  final List<KitabMetadata> kitabs;
  const ShelfGrid({super.key, required this.kitabs});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final columns = SettingsRepository.shelfColumns;
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: columns,
        childAspectRatio: 0.6,
        crossAxisSpacing: 16,
        mainAxisSpacing: 24,
      ),
      itemCount: kitabs.length,
      itemBuilder: (context, index) => KitabTile3D(kitab: kitabs[index]),
    );
  }
}