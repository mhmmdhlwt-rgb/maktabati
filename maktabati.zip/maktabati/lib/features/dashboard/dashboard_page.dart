import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:maktabati/data/repositories/kitab_repository.dart';
import 'package:maktabati/data/models/kitab_metadata.dart';
import 'widgets/shelf_grid.dart';
import 'widgets/global_search_overlay.dart';
import '../../l10n/app_localizations.dart';
import '../settings/settings_page.dart';

final kitabListProvider = FutureProvider<List<KitabMetadata>>((ref) async {
  return KitabRepository.getAllKitabs();
});

class DashboardPage extends ConsumerWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final loc = AppLocalizations.of(context);
    final kitabsAsync = ref.watch(kitabListProvider);
    return Scaffold(
      appBar: AppBar(
        title: Text(loc.dashboard),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => showSearchOverlay(context, ref),
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage())),
          ),
        ],
      ),
      body: kitabsAsync.when(
        data: (kitabs) => ShelfGrid(kitabs: kitabs),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
      ),
    );
  }

  void showSearchOverlay(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (_) => const GlobalSearchOverlay(),
    );
  }
}